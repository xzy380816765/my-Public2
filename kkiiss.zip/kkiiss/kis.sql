#设置客户端语言
SET NAMES UTF8;
#删除（丢弃）数据库kis，如果存在的话
DROP DATABASE IF EXISTS kis;
#创建数据库kis，使用UTF8作为数据库编码
CREATE DATABASE kis CHARSET=UTF8;
#进入数据库kis
USE kis;

#首页轮播图表kis_index_carousel

#首页商品栏目表kis_index_product

#商品表kis_laptop

#商品类型表kis_laptop_family：吊坠，转运珠，手镯，原创设计，戒指，领结

#商品详情图表kis_laptop_pic

#用户订单表kis_order

#用户订单详情表kis_order_detail

#用户收件地址表kis_receiver_address

#用户购物车表kis_shoppingcart_item

#用户信息表(kis_user)
CREATE TABLE kis_user(
	uid INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	uname VARCHAR(32),
	upwd VARCHAR(32),
	user_name VARCHAR(32),
	email VARCHAR(64),
	phone VARCHAR(16) NOT NULL UNIQUE,
	avatar VARCHAR(128),
	gender BOOL
);
INSERT INTO kis_user VALUES(11,'xuziyang','xu123456','王小明','380816765@qq.com','13131313131','C:',1);
INSERT INTO kis_user VALUES(22,'ziyang','xu12345','李小明','380816766@qq.com','13333333333','C:',1);
INSERT INTO kis_user VALUES(33,'xuzi','xu1234','张小明','380816767@qq.com','13503030303','C:',1);
INSERT INTO kis_user VALUES(44,'xuyang','xu123','宋小宝','380816768@qq.com','15770707070','C:',1);
INSERT INTO kis_user VALUES(55,'yang','xu1234567','黄晓明','380816769@qq.com','18244621902','C:',1);





