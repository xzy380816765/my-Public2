const express=require('express');
const bodyParser=require('body-parser');
const myPro=require('./routes/user.js');
//构建web服务器
var app=express();
app.listen(1314,()=>{
	console.log('服务器构建成功');
});
//托管静态文件
app.use(express.static('./myPro'));
//调用中间件
app.use(bodyParser.urlencoded({
	extended:false
}));
//使用路由器
//把路由器挂载到myPro下
app.use('/myPro',myPro);
