const express=require('express');
var router=express.Router();

var pool=require('../pool.js');
//注册
router.get('/selectPhone',(req,res)=>{
	var $phone=req.query.phone;
	if(!$phone){
		res.send('手机号码不能为空');
		return;
	}
	var sql="SELECT * FROM kis_user WHERE phone=?";
	pool.query(sql,[$phone],(err,result)=>{
		if(result.length>0){
			res.send("1");
		}else{
			res.send("0");
		}
	});
});
router.post('/register',(req,res)=>{
	var $phone=req.body.phone;
	if(!$phone){
		res.send('联系方式不能为空');
		return;
	}
	var $upwd=req.body.upwd;
	if(!$upwd){
		res.send('用户密码不能为空');
		return;
	}
	var $email=req.body.email;
	if(!$email){
		res.send('邮箱不能为空');
		return;
	}
	var $user_name=req.body.user_name;
	if(!$user_name){
		res.send('真实姓名不能为空');
		return;
	}
	var $gender=req.body.gender;
	if(!$gender){
		res.send('性别不能为空');
		return;
	}
	//sql语句
	var sql='INSERT INTO kis_user VALUES(null,?,?,?,?,?)';
	pool.query(sql,[$phone,$upwd,$user_name,$email,$gender],(err,result)=>{
		if(err) throw err;
			res.send('注册成功');
	});
});
//登录
router.post('/login',(req,res)=>{
	var $phone=req.body.phone;
	var $upwd=req.body.upwd;
	if(!$phone){
		res.send({code:200,msg:'用户名不能为空'});
		return;
	}
	if(!$upwd){
		res.send({code:200,msg:'密码不能为空'});
		return;
	}
	//构建sql语句
	var	sql='SELECT * FROM kis_user WHERE phone=? AND upwd=?';
	pool.query(sql,[$phone,$upwd],(err,result)=>{
		if (err) throw err;
		//console.log(result);
		if(result.length>0){
			res.send('登陆成功！');
		}else{
			res.send('用户名或密码错误！');
		}
	});
});
//导出
module.exports=router;
